package com.example.demo.global.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.resource.NoResourceFoundException;

@RestControllerAdvice
public class GlobalExceptionHandler {

	//if list is empty
	@ExceptionHandler(value = ListEmptyException.class)
	@ResponseStatus(value = HttpStatus.BAD_REQUEST)
	public ErrorResponse ListEmptyException(ListEmptyException lstException)
	{
		return new ErrorResponse(lstException.getMessage(),lstException.getStackTrace().toString());
	}
	
	//if url not found
	@ExceptionHandler(value = NoResourceFoundException.class)
	@ResponseStatus(value = HttpStatus.BAD_REQUEST)
	public ErrorResponse NoResourceFoundException(NoResourceFoundException noresorce)
	{
		return new ErrorResponse(noresorce.getMessage(),noresorce.getStatusCode().toString());
	}
}
