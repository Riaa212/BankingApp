package com.example.demo.domain;

import java.time.LocalDateTime;

import org.hibernate.annotations.processing.Pattern;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Student {

	@Id
	//@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	private String fname;
	private String lname;
	//private String dob;
	private String address;

	private String email;
	private Integer age;
	
	@Column(name = "created_date")
	private LocalDateTime date;
	
	//private String img;
	
}
