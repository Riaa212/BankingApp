package com.example.demo.controller;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.domain.Student;
import com.example.demo.proxy.StudentProxy;
import com.example.demo.service.impl.StudentServiceImpl;

@RestController
public class StudentController {

	@Autowired
	private StudentServiceImpl serviceImpl;
	
	@GetMapping("/getAll")
	public List<StudentProxy> getAll()
	{
		return serviceImpl.getAll();
	}
	
	@GetMapping("/saveBluckstd/{noStd}")
	public String saveStudents(@PathVariable("noStd") Integer id)
	{
		serviceImpl.saveBulkOfStudents(id);
		return "saved";
	}
	
	@GetMapping("/getAllSortedStd/{attrName}")
	public  List<StudentProxy> getAllSortedStudent(@PathVariable("attrName") String attrName){
		return  serviceImpl.getAllSortedStudent(attrName);
	}
	
	@GetMapping("/getStdPageWise/{pageNumber}/{pageSize}")
	public Page<Student> getStudentPageWise(@PathVariable("pageNumber") Integer pageNumber,@PathVariable("pageSize") Integer pageSize)
	{
	return serviceImpl.getStudentPageWise(pageNumber, pageSize);
	}
	
	@GetMapping("/getByFname/{name}")
	public List<StudentProxy> getAllUserBasedonFname(@PathVariable("name") String fname)
	{
		return serviceImpl.getStudentByFirstName(fname);
	}
	
	@GetMapping("/ageless/{age}")
	public List<StudentProxy> ageStudentProxy(@PathVariable("age") Integer age)
	{
		return serviceImpl.ageLessThan(age);
	}
	
	//find by fname and lname
	@GetMapping("/getfnamelname/{lname}/{fname}")
	public List<StudentProxy> getFirstOrLastName(@PathVariable("lname") String lname,@PathVariable("fname") String fname)
	{
		return serviceImpl.getByLastnameOrFirstname(lname, fname);
	}
	
	@DeleteMapping("/delete/{fname}")
	public String deleteById(@PathVariable("fname") String fname)
	{
		
		serviceImpl.deleteByFname(fname);
		return "deleted successfully";		
	}
	
	@GetMapping("/getDateBefore/{date}")
	public List<StudentProxy> getDateBefore(@PathVariable("date") LocalDateTime date)
	{
		return serviceImpl.getByDateBefore(date);
	}
	
	@GetMapping("/getByName/{fname}/{lname}")
	public List<StudentProxy> getByFistnameAndLname(@PathVariable("fname") String fname,@PathVariable("lname") String lname)
	{
		return serviceImpl.findByFnameOrLname(fname, lname);
	}
	
	@DeleteMapping("/deleteByEmail/{email}")
	public String deleteByEmail(@PathVariable("email") String email)
	{
		serviceImpl.deleteByEmail(email);
		return "deleted successfully";
	}
	
	@GetMapping("/getByEmail/{email}")
	public StudentProxy getByEmail(@PathVariable("email") String email)
	{
		return serviceImpl.findByEmail(email);
	}
	
	@DeleteMapping("/deleteLname/{lname}")
	public String deleteByLname(@PathVariable("lname") String lname)
	{
		serviceImpl.deleteByLname(lname);
	    return "deleted successfully";	
	}
	
	@PutMapping("/updatestd/{fname}/{id}")
	public String updateStudent(@PathVariable("fname") String fname,@PathVariable("id") Integer id)
	{
		serviceImpl.updateStudent(fname, id);
		return "Student updated successfully"; 	
	}
	
	@PostMapping("/insert")
	public String insert(@RequestBody StudentProxy stdProxy)
	{
		/**
		try {
			serviceImpl.InsertStudent(stdProxy);
			return "Inserted successfully";	
		}
		catch (Exception e) {
			return "invalid data access exception";
		}**/
		serviceImpl.InsertStudent(stdProxy);
		return "Inserted successfully";	
		//return null;
	}
	
	@GetMapping("/orderByAge")
	public List<StudentProxy> orderByAge()
	{
		return serviceImpl.orderByAge();
	}

}
