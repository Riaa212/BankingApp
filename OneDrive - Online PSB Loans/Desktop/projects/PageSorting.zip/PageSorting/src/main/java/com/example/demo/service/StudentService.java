package com.example.demo.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.jpa.repository.Query;

import com.example.demo.domain.Student;
import com.example.demo.proxy.StudentProxy;

public interface StudentService {

	public String saveBulkOfStudents(Integer noOfStudents);
	
	//save student
	public String saveStudent(StudentProxy studentProxy);
	
	//get all
	public List<StudentProxy> getAll();	
	
	//get all sorted student
	public List<StudentProxy> getAllSortedStudent(String attrName);
	
	//get studentPageWise
	public Page<Student> getStudentPageWise(Integer pageNumber,Integer pageSize);
	
	public List<StudentProxy> getStudentByFirstName(String fname);

	//age less than
	public List<StudentProxy> ageLessThan(Integer age);
	
	public List<StudentProxy> getByLastnameOrFirstname(String fname,String lname);

	public List<StudentProxy> getByDateBefore(LocalDateTime date);
	
	public String deleteByFname(String fname);
	
	public List<StudentProxy> findByFnameOrLname(String fname,String lname);
	
	public void deleteByEmail(String email);
	
	public StudentProxy findByEmail(String email);
	
	public void deleteByLname(String lname);
	
	public String updateStudent(String fname,Integer id);
	
	public String InsertStudent(StudentProxy student);
	
	public List<StudentProxy> orderByAge();
	
 }
