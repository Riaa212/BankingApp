package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.demo.domain.Address;
import jakarta.transaction.Transactional;

public interface AddressRepository extends JpaRepository<Address, Integer>
{
	@Modifying
	@Transactional
	@Query("INSERT INTO Address(city,state) VALUES(:city,:state)")
	void saveAddress(@Param("city") String city,@Param("state") String state);
}
