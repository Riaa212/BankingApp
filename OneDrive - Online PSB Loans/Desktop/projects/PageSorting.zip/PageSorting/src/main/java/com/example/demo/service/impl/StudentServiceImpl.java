package com.example.demo.service.impl;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.UnexpectedRollbackException;

import com.example.demo.domain.Student;
import com.example.demo.global.exception.ListEmptyException;
import com.example.demo.helper.Helper;
import com.example.demo.proxy.StudentProxy;
import com.example.demo.repository.AddressRepository;
import com.example.demo.repository.StudentRepository;
import com.example.demo.service.StudentService;
import com.github.javafaker.Faker;
import com.github.javafaker.File;

import jakarta.transaction.Transactional;

@Service
public class StudentServiceImpl implements StudentService
{

	@Autowired
	private StudentRepository studentRepository;
	
	@Autowired
	private AddressRepository addressRepository;
	
	@Autowired
	private Helper helper;

	//save students
	@Override
	public String saveStudent(StudentProxy studentProxy) {
		helper.convertStudentProxyToEntity(studentProxy);
		return null;
	}

	//get all students
	@Override
	public List<StudentProxy> getAll() {

		List<Student> stdList=studentRepository.findAll();
		return 	helper.convertStudentListEntityToProxy(stdList);
	}
	
	//generate students
	private Student generateStudent()
	{
	LocalDateTime curreDateTime=LocalDateTime.now();
	Faker f=new Faker();
	Student student=new Student();
	student.setFname(f.name().firstName());
	student.setLname(f.name().lastName());
	student.setAddress(f.address().fullAddress());
	student.setAge(f.date().birthday().getYear());
	//curreDateTime.minusYears(f.date().birthday().getYear());
	//student.getImg(f.avatar().image().toString());
	student.setEmail(f.name().firstName()+"."+"@gmail.com");
	student.setDate(curreDateTime.minusYears(f.date().birthday().getYear()));
	return student;
	}

	//get all sorted student
	@Override
	public List<StudentProxy> getAllSortedStudent(String attrName) {	
		List<Student> stdList=studentRepository.findAll(Sort.by(Sort.Direction.DESC, attrName));
		return 	helper.convertStudentListEntityToProxy(stdList);
	}

	//save bulk of student
	@Override
	public String saveBulkOfStudents(Integer noOfStudents) {

		for(int i=0;i<noOfStudents;i++)
		{
			studentRepository.save(generateStudent());
		}
		return null;
	}


	//get student page wise
	@Override
	public Page<Student> getStudentPageWise(Integer pageNumber, Integer pageSize) {
		
		Page<Student> page=	studentRepository.findAll(PageRequest.of(pageNumber,pageSize));
		return page;
	}

	//get student by firstname
	@Override
	public List<StudentProxy> getStudentByFirstName(String fname) {
		
		List<Student> std=studentRepository.findByFname(fname);
		
		if(std.isEmpty())
		{
			throw new ListEmptyException("List is empty");
		}
		return 	helper.convertStudentListEntityToProxy(std);
	}

	//get student whose age is less than given age
	@Override
	public List<StudentProxy> ageLessThan(Integer age) {
		
		List<Student> stdStudent=studentRepository.findByAgeLessThan(age);
		
		return helper.convertStudentListEntityToProxy(stdStudent);
	}
	
	
	//get last name or first name
	@Override
	public List<StudentProxy> getByLastnameOrFirstname(String lname, String fname) {

		List<Student> getList=studentRepository.findByLnameOrFname(lname, fname);
	
		return 	helper.convertStudentListEntityToProxy(getList);
	}

	@Override
	public List<StudentProxy> getByDateBefore(LocalDateTime date) {

		List<Student> sdate=studentRepository.findByDateBefore(date);
		
		return 	helper.convertStudentListEntityToProxy(sdate);
	}

	@Override
	public String deleteByFname(String fname) {
		studentRepository.deleteByFname(fname);
		return "deleted successfully";
	}

	@Override
	public List<StudentProxy> findByFnameOrLname(String fname, String lname) {
		
		List<Student> stdList=studentRepository.findByFnameOrLname(fname, lname);		
		return 	helper.convertStudentListEntityToProxy(stdList);
	}

	@Override
	public void deleteByEmail(String email) {

		studentRepository.deleteByEmail(email);
	}

	//Brandy@gmail.com
	@Override
	public StudentProxy findByEmail(String email) {
		
		Student stdemail=studentRepository.findByEmail(email);
		
		return 	helper.convStudentEntityToProxy(stdemail);
	}

	@Override
	public void deleteByLname(String lname) {
		studentRepository.deleteByLname(lname);
	}

	@Override
	public String updateStudent(String fname, Integer id) {
		studentRepository.updateStudent(fname, id);
		return null;
	}

	
	@Override
	@Transactional
	public String InsertStudent(StudentProxy studentProxy) {
		try {
			studentRepository.InsertStudent(studentProxy.getFname(),studentProxy.getLname());
			
			addressRepository.saveAddress("AHD", "GJ");	
		}
		catch (Exception e) {
			//e.printStackTrace();
			System.out.println(e);
		}
		return null;
	}

	@Override
	public List<StudentProxy> orderByAge() {
		List<Student> stdStudent=studentRepository.OrderByAgeStudentNative();
		return helper.convertStudentListEntityToProxy(stdStudent);
	}
}
