package com.example.demo.repository;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.demo.domain.Student;

import jakarta.transaction.Transactional;

public interface StudentRepository extends JpaRepository<Student, Integer>
{
	List<Student> findByFname(String fname);
	
	List<Student> findByAgeLessThan(Integer age);
	
	List<Student> findByLnameOrFname(String fname,String lname);
	
	List<Student> findByDateBefore(LocalDateTime date);

	//delete by lname
	@Transactional
	Integer deleteByFname(String fname);
	
	//find by fname or lname
	@Query("SELECT s FROM Student s WHERE s.fname=:fnm OR s.lname=:lnm")
	List<Student> findByFnameOrLname(@Param("fnm") String fname,@Param("lnm") String lname);
	

	//delete by lname
	@Modifying
	@Transactional
	@Query("DELETE FROM Student s WHERE s.lname=:e")
	void deleteByLname(@Param("e") String lname);
	
	//delete by email
	@Transactional
	void deleteByEmail(String email);

	//find by email
	Student findByEmail(String email);
	
	
	//update student
	@Modifying
	@Transactional
	@Query("UPDATE Student s SET s.fname=:fnm Where s.id=:id")
	void updateStudent(@Param("fnm") String fname,@Param("id") Integer id);
	
	//insert
	@Modifying
	@Transactional
	@Query("INSERT INTO Student(fname,lname) VALUES(:fname,:lname)")
	void InsertStudent(@Param("fname") String fname,@Param("lname") String lname);

		//order by descending native query
		@Modifying
		@Transactional
		@Query(value="SELECT * FROM Student ORDER BY age DESC",nativeQuery =true)
		List<Student> OrderByAgeStudentNative();
}
