package com.example.demo.helper;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.domain.Student;
import com.example.demo.proxy.StudentProxy;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class Helper {

	@Autowired
	private ObjectMapper mapper;
	
	//get list of students
	public List<StudentProxy> convertStudentListEntityToProxy(List<Student> students)
	{
	return students.stream().map(a->mapper.convertValue(a, StudentProxy.class)).toList();
	}
	
	//convert student proxy to entity
	public Student convertStudentProxyToEntity(StudentProxy studentProxy)
	{
		return mapper.convertValue(studentProxy, Student.class);
	}
	
	public StudentProxy convStudentEntityToProxy(Student student)
	{
		return mapper.convertValue(student, StudentProxy.class);
	}
}
