package com.example.security.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.security.domain.Emp;

public interface EmpRepo extends JpaRepository<Emp, Integer>
{
	Emp	findByUserName(String name);
}
