package com.example.security.cofiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.method.configuration.GlobalMethodSecurityConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;

//@EnableWebSecurity
//@EnableGlobalMethodSecurity(prePostEnabled = true, 
//securedEnabled = true)
//extends GlobalMethodSecurityConfiguration
@Configuration
public class SecurityConfig {

	
	@Bean
	public SecurityFilterChain securityFilterChain(HttpSecurity httpSecurity) throws Exception
	{
		//disble csrf tocken
		httpSecurity.csrf(a->a.disable());
		//httpSecurity.formLogin(Customizer.withDefaults());
		httpSecurity.sessionManagement(s->s.sessionCreationPolicy(SessionCreationPolicy.STATELESS));
		
		httpSecurity.authorizeHttpRequests(auth->auth.requestMatchers("/","/loginForm","/csrf").permitAll()
			.requestMatchers("/test").hasAnyAuthority("USER")
			.requestMatchers("/getAll/**").hasAuthority("ADMIN").anyRequest().authenticated()
			);
		
		//httpSecurity.authorizeHttpRequests(a->a.requestMatchers("/getAll").hasAnyRole("ROLE_ADMIN").anyRequest().authenticated());	
		
		httpSecurity.formLogin(Customizer.withDefaults());
		//httpSecurity.httpBasic(Customizer.withDefaults());
		//httpSecurity.sessionManagement(s -> s.sessionCreationPolicy(SessionCreationPolicy.STATELESS));
		return httpSecurity.build();
	}
	
	@Bean
	public UserDetailsService userDetailsService()
	{
		return new CustomUserService();
	}
	
	@Bean
	public DaoAuthenticationProvider daoAuthenticationProvider()
	{
		DaoAuthenticationProvider doP=new DaoAuthenticationProvider();
		doP.setUserDetailsService(userDetailsService());
		doP.setPasswordEncoder(byBCryptPasswordEncoder());
		return doP;
	}
	
	@Bean
	public BCryptPasswordEncoder byBCryptPasswordEncoder()
	{
		return new BCryptPasswordEncoder();
	}
	
	/**
	//in memory authentication
	@Bean
	protected UserDetailsService userDetails()
	{
		UserDetails user1=User.withUsername("Riya").password("1234").build();
		
		//UserDetails user2=User.withUsername("John").password("3456").build();
		
		return new InMemoryUserDetailsManager(user1);
	} **/
	
	/**
	@Bean
	public PasswordEncoder passwordEncoder() {
	    return NoOpPasswordEncoder.getInstance();
	} **/
	
}
