package com.example.security.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.security.domain.Manager;
import com.example.security.gobal.exception.ErrorResponse;
import com.example.security.repository.ManagerRepo;
import com.example.security.service.ManagerService;

import jakarta.servlet.http.HttpServletRequest;

@Service
public class ManagerServiceImpl  implements ManagerService{

	//static List<Manager> managers=new ArrayList<>();
	
	@Autowired
	private ManagerRepo repo;
	
	@Autowired
	private BCryptPasswordEncoder passwordEncoder;
	
	@Autowired
	private ErrorResponse errorResponse;
	
	@Override
	public List<Manager> getAll() {
		return repo.findAll();
	}

	
	@Override
	public String saveData(Manager manager) {
		
		String encodepwd=passwordEncoder.encode(manager.getPassword());
		//boolean matches = encodepwd.matches(encodepwd);
		manager.setPassword(encodepwd);
		//manager.setRole("ROLE_USER");
		repo.save(manager);
		
		//managers.add(manager);
		return "data saved";
	}

	
	//delete by id
	public List<Manager> deleteById(Integer id)
	{
		//Optional<Manager> findFirst = managers.stream().filter(a->a.getId().equals(id)).findFirst();
		//managers.removeIf(a->a.getId().equals(id));
		repo.deleteById(id);
		return getAll();
	}

	//update by id
	public String updateById(Manager manager,Integer id)
	{
		Optional<Manager> findByIdManager=repo.findById(id);
		
		if(findByIdManager != null)
		{
			Manager manager2 = findByIdManager.get();
			manager2.setName(manager.getName());
			manager2.setEmail(manager.getEmail());
			manager2.setCity(manager.getCity());
			
			repo.save(manager2);
		}
		return "updated successfully";
	}
	
	//get session id
	public String getSessionId(HttpServletRequest httpServletRequest)
	{
		return	httpServletRequest.getSession().getId();
	}
}