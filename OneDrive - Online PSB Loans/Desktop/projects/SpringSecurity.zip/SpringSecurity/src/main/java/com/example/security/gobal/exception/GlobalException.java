package com.example.security.gobal.exception;

import java.nio.file.AccessDeniedException;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalException {

	@ExceptionHandler(value = AccessDeniedException.class)
	@ResponseStatus(code = HttpStatus.FORBIDDEN)
	public ErrorResponse accessDeniedException(AccessDeniedException accessDeniedException)
	{
		return new ErrorResponse("Access denied");	
	}
	
	/**
	@ExceptionHandler(value = Exception.class)
	public ErrorResponse excErrorResponse(Exception exception)
	{
		return new ErrorResponse("exceptions");
	} **/
}
