package com.example.security.service;

import java.util.List;

import com.example.security.domain.Manager;

public interface ManagerService {

	public String saveData(Manager managers);
	
	public List<Manager> getAll(); 
}
