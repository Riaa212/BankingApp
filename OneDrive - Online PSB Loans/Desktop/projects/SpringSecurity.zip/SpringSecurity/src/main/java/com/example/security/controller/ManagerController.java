package com.example.security.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.security.domain.Manager;
import com.example.security.service.impl.ManagerServiceImpl;

import io.jsonwebtoken.Claims;
import jakarta.servlet.http.HttpServletRequest;

@RestController
public class ManagerController {

	@Autowired
	private ManagerServiceImpl serviceImpl;
	
	@GetMapping("/")
	public String wlc()
	{
		return "welcome page";
	}
	
	//get all manager
	@GetMapping("/getAll")
	//@PreAuthorize("hasRole('ROLE_USER')")
	public List<Manager> getAll()
	{
	return	serviceImpl.getAll();	
	}
	
	//save manager data
	@PostMapping("/save")
	//@PreAuthorize("hasRole('ROLE_ADMIN')") //admin can add manager
	public String savedata(@RequestBody Manager manager)
	{
		serviceImpl.saveData(manager);
		return "Saved successfully";
	}
	
	@GetMapping("/loginForm")
	public String loginForm()
	{
		return "loginForm";
	}
	
	//get session id
	@GetMapping("/getSession")
	public String getSessionId(HttpServletRequest request)
	{
		return "Session Id:"+ serviceImpl.getSessionId(request);
	}
	
	@GetMapping("/csrf")
	public CsrfToken getCsrf(HttpServletRequest request)
	{
		return (CsrfToken) request.getAttribute("_csrf");
	}
	
	//delete manager by id
	@DeleteMapping("/delete/{id}")
	//@PreAuthorize("hasRole('ROLE_ADMIN')") //only admin can delete manager by id
	public List<Manager> deleteById(@PathVariable("id") Integer id)
	{
		return serviceImpl.deleteById(id);
	}
	

	//@PreAuthorize("hasRole('ROLE_ADMIN')")
	//@PostAuthorize("hasRole('ROLE_ADMIN')")
	@GetMapping("/test")
	public String authenticate()
	{
		return "authenticated successfully";
	}
	
	//update by id
	@PostMapping("/update/{id}")
	public String updateById(@RequestBody Manager manager,@PathVariable("id") Integer id)
	{
		serviceImpl.updateById(manager, id);
		return "updated successfully";
	}
}
