package com.example.security.cofiguration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import com.example.security.domain.Manager;
import com.example.security.repository.ManagerRepo;

@Component
public class CustomUserService implements UserDetailsService
{

	@Autowired
	private ManagerRepo repo;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Manager findByName = repo.findByName(username);
		
		if(findByName == null)
		{
			 throw new UsernameNotFoundException("User not found");
		}
		return new CustomUser(findByName);
	}

}
