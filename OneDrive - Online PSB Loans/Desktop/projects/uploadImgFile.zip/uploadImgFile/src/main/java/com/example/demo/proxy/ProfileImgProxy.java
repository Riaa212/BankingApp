package com.example.demo.proxy;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProfileImgProxy {

	public ProfileImgProxy(ErrorMsg errorMsg)
	{
		this.errorMsg=errorMsg;
	}
	private Integer id;
	private String fileName;
	private Long fileSize;
	private String fileId;
	private String contentType;

	private ErrorMsg errorMsg;
	
	private byte[] img;

}
