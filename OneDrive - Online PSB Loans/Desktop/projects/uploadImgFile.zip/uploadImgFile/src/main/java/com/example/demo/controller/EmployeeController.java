package com.example.demo.controller;

import java.io.IOException;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.example.demo.domain.Employee;
import com.example.demo.proxy.EmployeeProxy;
import com.example.demo.proxy.ProfileImgProxy;
import com.example.demo.service.impl.EmployeeServiceImpl;

import jakarta.annotation.Resource;
import jakarta.servlet.http.HttpServletResponse;

@RestController
public class EmployeeController {

	@Autowired
	private EmployeeServiceImpl serviceImpl;
	
	@PostMapping("/upload") //working
	private String upload(@RequestParam("file") MultipartFile file)
	{
		serviceImpl.uploadImg(file);
		return "Uploaded successfully";
	}
	
	@GetMapping("/download/{fid}") //not working
	public ResponseEntity<byte[]> downloadImg(@PathVariable("fid") String fid)
	{
		ProfileImgProxy profileImgProxy=serviceImpl.downloadImg(fid);
	
		return 	ResponseEntity.status(HttpStatus.OK).contentType(MediaType.valueOf(profileImgProxy.getContentType())).body(profileImgProxy.getImg());
	}
	/**
	@PostMapping("/uploadDynamic")
	public String uploadFileOnDynamicPath(@RequestParam("file") MultipartFile file)
	{
		return 	serviceImpl.uploadImgToDynamicPath(file);
	}**/
	
	@PostMapping("/uploadDynamicPath") //working
	public ResponseEntity<String> uploadDocumentToPath(@RequestParam("profileImage") MultipartFile file,@ModelAttribute("emp") EmployeeProxy employeeProxy) {
		return ResponseEntity.status(HttpStatus.OK).body(serviceImpl.uploadImgToDynamicPath(file,employeeProxy));
	}
	
	
	//download dynamic path
	@GetMapping("/downloadDynamicPath/{id}")  //working
	public ResponseEntity<byte[]> downloadFromDynamicPath( @PathVariable("id") String fid)
	{
		ProfileImgProxy pidImg=serviceImpl.downloadImgFromDynamicPath(fid);
		return ResponseEntity.status(HttpStatus.OK).
				header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + pidImg.getFileId() + "\"")
		.body(pidImg.getImg());
		//.body(pidImg);	
	}
	
	//download zip file based on employee id
	//download dynamic path
	@GetMapping("/downloadEmpDynamicPath/{id}")
	public ResponseEntity<byte[]> downloadEmpFromDynamicPath(@PathVariable("id") Integer fid)
	{
		EmployeeProxy pidImg=serviceImpl.downloadImgByEmpIdFromDynamicPath(fid);
		
		System.out.println("img:"+ pidImg.getProfileImg().getImg());
		return ResponseEntity.status(HttpStatus.OK).
				header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + serviceImpl.downloadImgByEmpIdFromDynamicPath(fid) + "\"")
		.body(pidImg.getProfileImg().getImg());
	}
	
	//upload list of dynamic path
	@PostMapping("/uploadListOfImgToDynamicPath")
	public ResponseEntity<ProfileImgProxy> uploadListOfDocumentToPath(@RequestParam("profileImage") MultipartFile[] file) {
		return ResponseEntity.status(HttpStatus.OK).body(serviceImpl.uploadMultipleFiles(file));
	}
	

	@GetMapping("/downloadImages")
	public void getallImages(HttpServletResponse response) throws IOException {
		 serviceImpl.downloadListOfFiles(response);
	}
	
	//upload excel file
	@PostMapping("/uploadExcelFile")
	public ResponseEntity<?> uploadExcelFile(@RequestParam("file") MultipartFile excelFile)
	{
		String objectFromExcel=null;
		if(excelFile!=null &&  excelFile.getContentType().equals("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
		{
			objectFromExcel = serviceImpl.getObjectFromExcel(excelFile);
		}
		
		//System.out.println(excelFile.getSize());
		//System.out.println(excelFile.getOriginalFilename());
		//System.out.println(excelFile.getContentType()); 
		return new ResponseEntity<>(Map.of("status",objectFromExcel),HttpStatus.OK);
	}
	
	
	  //download blank format
	  @GetMapping("/downloadExcelFormatFile") //working
	  public ResponseEntity<?> uploadBlankExcelFile()
	  {
		  String file_Name="empBlankExcel.xlsx";
		 
		  return ResponseEntity.ok()
		 	        .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename="+file_Name)
		 	        .contentType(MediaType.parseMediaType("application/vnd.ms-excel"))
		 	        .body(serviceImpl.downloadExcelBlankExcelFile());
	  }
	

		//download excel file
		@GetMapping("/downloadExcelFile") //working
		  public ResponseEntity<byte[]> getFile() {
			 
		     return ResponseEntity.ok()
		        .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=")
		        .contentType(MediaType.parseMediaType("application/vnd.ms-excel"))
		        .body(serviceImpl.downloadExcelFile().toByteArray());
		  }
		  
	/**
	@GetMapping("/downloadAllFiles")
	public ResponseEntity<byte[]> downloadAllFiles()
	{
		return ResponseEntity.status(HttpStatus.OK).
				header(HttpHeaders.CONTENT_DISPOSITION,  "\"")
		.body(pidImg.getImg());	
	} **/ 
	

	 
}
