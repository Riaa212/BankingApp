package com.example.demo.service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.example.demo.domain.Employee;
import com.example.demo.proxy.EmployeeProxy;
import com.example.demo.proxy.ProfileImgProxy;

import jakarta.servlet.http.HttpServletResponse;

public interface EmployeeService
{
	public String uploadImg(MultipartFile file);
 
	public ProfileImgProxy downloadImg(String fid);
	
	public String uploadImgToDynamicPath(MultipartFile file,EmployeeProxy empProxy);
	
	public EmployeeProxy downloadImgByEmpIdFromDynamicPath(Integer eid);
	
	public ProfileImgProxy downloadImgFromDynamicPath(String fid);
	
	//public ProfileImgProxy downloadListOfFiles() throws IOException;
	
	public void downloadListOfFiles(HttpServletResponse response) throws IOException;
	
	public ProfileImgProxy uploadMultipleFiles(MultipartFile[] file);
	
	public List<String> findByImg();
	
	public String getObjectFromExcel(MultipartFile excelFile);
	
	//public static ByteArrayInputStream empToExcel(List<Employee> employees);

	public ByteArrayOutputStream downloadExcelFile(); //working
}
