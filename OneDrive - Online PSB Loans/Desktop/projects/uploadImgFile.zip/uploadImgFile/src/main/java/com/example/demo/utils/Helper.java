package com.example.demo.utils;

import java.io.IOException;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

import com.example.demo.domain.Employee;
import com.example.demo.domain.ProfileImg;
import com.example.demo.proxy.EmployeeProxy;
import com.example.demo.proxy.ProfileImgProxy;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class Helper {

	@Autowired
	private ObjectMapper mapper;
	
	public ProfileImg convertProxyToEntity(ProfileImgProxy profileProxy)
	{
	return	mapper.convertValue(profileProxy,ProfileImg.class);
	}
	
	public Employee convertEmployeeProxyToEntity(EmployeeProxy employeeProxy)
	{
		return mapper.convertValue(employeeProxy,Employee.class);
	}
	
	public EmployeeProxy convertEmployeeProxyToEntity(Employee employee)
	{
		return mapper.convertValue(employee,EmployeeProxy.class);
	}
	
	public ProfileImgProxy convertEntityToProxy(ProfileImg profileImg)
	{
		return mapper.convertValue(profileImg, ProfileImgProxy.class);
	}
	
	
	//this method is going to generate unique file name
	public static String getUniqueFileName(String OriginalName)
	{
		String uuid=UUID.randomUUID()+OriginalName.substring(OriginalName.lastIndexOf("."));
		 return uuid;
	}
	
	public List<ProfileImgProxy> convertListOfEntityToProxy(List<ProfileImg> profileImgs)
	{
		return profileImgs.stream().map(a->mapper.convertValue(a, ProfileImgProxy.class)).toList();
	}
	
	public List<EmployeeProxy> convertEmpListEntityToProxy(List<Employee> emps)
	{
		return emps.stream().map(a->mapper.convertValue(a,EmployeeProxy.class)).toList();
	}
}
