package com.example.demo.utils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.example.demo.domain.Employee;

public class ExcelHelper {

	public static List<Employee> getEmployeesObjs(InputStream is)
	{
		List<Employee> employees=new ArrayList<>();
		
		try {
			
			//create work book object
			Workbook workbook=new XSSFWorkbook(is);
			
			//get sheet
			Sheet sheet = workbook.getSheet("empdb");
			
			Iterator<Row> rowItr = sheet.iterator();

	
			int rowCount=0;
			while(rowItr.hasNext())
			{
				Row row = rowItr.next();

				if(rowCount==0)
				{
					rowCount++;
					continue;
				}
				Employee emp=new Employee();
				Iterator<Cell> cell = row.iterator();
	
				System.out.println("row count:"+rowCount);
				int cellCount=1;
				
				while(cell.hasNext())
				{
					Cell next = cell.next();
					switch (cellCount)
					{
					case 1: {
						emp.setName(next.getStringCellValue());
						System.out.println(emp.getName());
						break;
					}
					case 2:
					{
						emp.setDob(next.getDateCellValue().toString());
						System.out.println(emp.getDob());
						break;
					}
					case 3:
					{
						emp.setAddress(next.getStringCellValue());
						System.out.println(emp.getAddress());
						break;
					}
					default:
						break;
					}//switch end
					cellCount++;
					System.out.println("cell count:"+cellCount);
				}//cell iterator
				employees.add(emp);
				employees.stream().forEach(e->System.out.println("employee list:"+e));
			}//row iterator
			workbook.close();
		} //try end
		catch (Exception e) {
			e.printStackTrace();
		}
		return employees;
	}
	
	//download excel file
	//@Override
	public static ByteArrayOutputStream empToExcel(List<Employee> employees) { //working

		 String[] HEADERs = { "id","address", "dob", "name" };
		 
	    try (Workbook workbook = new XSSFWorkbook();
	    		ByteArrayOutputStream out = new ByteArrayOutputStream();) {
	    	
	      Sheet sheet = workbook.createSheet("test");
	     
	      
	     System.out.println("get First row num:"+ sheet.getFirstRowNum());
	      sheet.getScenarioProtect();
	      // Header
	      Row headerRow = sheet.createRow(0);
	      
	      Row row2 = sheet.getRow(0);
	      
	  //    headerRow.getCell(0).setAsActiveCell();
	      
	      //set first row locked
	     // row2.getRowStyle().setLocked(true);
	      
	      //cell.getCellStyle().setLocked(true);
	      
	      for (int col = 0; col < HEADERs.length; col++) {
	        Cell cell = headerRow.createCell(col);
	  
	        cell.setCellValue(HEADERs[col]);
	      }
	      
	      int rowIdx = 1;
	      for (Employee emps : employees) {
	    	 
	        Row row = sheet.createRow(rowIdx++);

	        row.createCell(0).setCellValue(emps.getId());
	        row.createCell(1).setCellValue(emps.getAddress());
	        row.createCell(2).setCellValue(emps.getDob());
	        row.createCell(3).setCellValue(emps.getName());	 
	        
	      }
	      workbook.write(out);
	      return out;
	    } catch (IOException e) {
	      throw new RuntimeException("fail to import data to Excel file: " + e.getMessage());
	    }
	  }
}
