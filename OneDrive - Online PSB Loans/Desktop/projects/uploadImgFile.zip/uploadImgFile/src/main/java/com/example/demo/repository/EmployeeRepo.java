package com.example.demo.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.demo.domain.ProfileImg;

public interface EmployeeRepo extends JpaRepository<ProfileImg, Integer>
{
	
	Optional<ProfileImg> findByFileId(String fid); //find image by id

	//void findByImg();

	//@Query(name = "select d.fileName from profile_img d where d.content_type='image'")
	//ProfileImg findByImg();
	
	@Query(value="select p.fileName  from  ProfileImg p where p.contentType like 'image/%'")
	List<String> allImg();
}
