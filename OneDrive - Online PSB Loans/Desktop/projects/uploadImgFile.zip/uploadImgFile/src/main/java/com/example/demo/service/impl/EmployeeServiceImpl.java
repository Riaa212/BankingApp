package com.example.demo.service.impl;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Service;
import org.springframework.util.StreamUtils;
import org.springframework.web.multipart.MultipartFile;

import com.example.demo.domain.Employee;
import com.example.demo.domain.ProfileImg;
import com.example.demo.proxy.EmployeeProxy;
import com.example.demo.proxy.ErrorMsg;
import com.example.demo.proxy.ProfileImgProxy;
import com.example.demo.repository.EmployeeEntityRepo;
import com.example.demo.repository.EmployeeRepo;
import com.example.demo.service.EmployeeService;
import com.example.demo.utils.ExcelHelper;
import com.example.demo.utils.Helper;

import jakarta.servlet.http.HttpServletResponse;

//list of file store
//download zip file -get list of fid then zip all file one by one

@Service
public class EmployeeServiceImpl implements EmployeeService
{
	@Autowired
	private Helper mapper;
	
	@Autowired
	private EmployeeRepo repo;

	@Autowired
	private EmployeeEntityRepo employeeRepo;

	
	@Override
	public String uploadImg(MultipartFile file) { //working
		
		ProfileImg profileImg=new ProfileImg();
	
		profileImg.setFileName(file.getOriginalFilename());
		profileImg.setFileSize(file.getSize());
		profileImg.setContentType(file.getContentType());
		
		try {
			//profileImg.setImg(file.getBytes());
		
		String uuid=UUID.randomUUID().toString();
		String fileName=file.getOriginalFilename();
		
		//int lastIndexOf=fileName.lastIndexOf(".");
		
		//String ext=fileName.substring(lastIndexOf);
		
		//tring finalStr=uuid.concat(ext);
	
		String finalStr=mapper.getUniqueFileName(fileName);
		profileImg.setFileId(finalStr);
		
		repo.save(profileImg);
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return "record savedd" + profileImg;
	}

	@Override
	public ProfileImgProxy downloadImg(String fid) { //not working
	
		Optional<ProfileImg> pidImg=repo.findByFileId(fid);
		
		if(pidImg.isPresent())
		{
		return mapper.convertEntityToProxy(pidImg.get());
		}
		
		ErrorMsg errorMsg=ErrorMsg.builder().errorCode("223").errorMsg("error..").build();
		return new ProfileImgProxy(errorMsg);
	}
	
		//upload img to dynamic path and with employee details
		@Override
		public String uploadImgToDynamicPath(MultipartFile file,EmployeeProxy empProxy) { //working
		
			String fileName=null;
			
			ProfileImg profileImg=null;
			
			try {
				
				//String urlPath = new ClassPathResource("").getFile().getAbsolutePath() + File.separator + "static"+ File.separator + "documents";
			
				String urlPath="C:\\Users\\RiyaRami\\Documents\\workspace-spring-tool-suite-4-4.17.2.RELEASE\\uploadImgFile\\src\\main\\resources\\static\\documents";
			
				File f=new File(urlPath);
				
				if(!f.exists())
				{
					f.mkdir();
				}
				
			fileName=file.getOriginalFilename();
				
			String finalPath=urlPath+File.separator+fileName;
			
			//copy file path into dynamic path
			Files.copy(file.getInputStream(),Paths.get(finalPath),StandardCopyOption.REPLACE_EXISTING);
		 
			ProfileImg pid=new ProfileImg();
			 pid.setFileName(finalPath);
			 pid.setContentType(file.getContentType());
			 pid.setFileSize(file.getSize());
			 pid.setFileId(mapper.getUniqueFileName(finalPath));
			 pid.setImg(file.getBytes());
	
			//save image/file data in folder
			 profileImg=repo.save(pid);
			 
			 //empProxy.setProfileImg(mapper.convertEntityToProxy(profileImg));
			 
			 Employee emp=mapper.convertEmployeeProxyToEntity(empProxy);
			
			 //set emp id
			 
			 //uncomment- emp.setProfileImg(pid);
			 
			 employeeRepo.save(emp);
			 
			 System.out.println(""+emp);
			 System.out.println(pid.getId());
			
				//empProxy.getProfileImg().setId(pid.getId());
			}
			catch (Exception e) {
				e.printStackTrace();
			}
			return "File have been saved with "+(Objects.isNull(profileImg) ? "Id not found":profileImg.getId());
		}
		
		//downloasImg from dynamic path
	@Override 
	public ProfileImgProxy downloadImgFromDynamicPath(String fid) //working
	{
		ProfileImg pidImg=null;
		
		try
		{
		pidImg=repo.findByFileId(fid).get();

		//String fileName=file.getOriginalFilename();
		
		String urlPath = new ClassPathResource("").getFile().getAbsolutePath() + File.separator + "static"+ File.separator + "documents";

		System.out.println("urlPath:"+urlPath);
		
		String absolutePath=urlPath+File.separator+pidImg.getFileName();
		
		System.out.println("absolutePath"+absolutePath);
				
		byte[] allbytes=Files.readAllBytes(new File(absolutePath).toPath());
		
		pidImg.setImg(allbytes);
	
		}
		catch (Exception e) {
		
			e.printStackTrace();
		}
		
		return mapper.convertEntityToProxy(pidImg);
	}

	@Override
	public EmployeeProxy downloadImgByEmpIdFromDynamicPath(Integer eid) //not working
	{
		Employee empid=null;
		ProfileImg pid=null;
		try
		{

		Optional<Employee> empId=employeeRepo.findById(eid);
		
		if(empId.isPresent())
		{			
			String urlPath = new ClassPathResource("").getFile().getAbsolutePath() + File.separator + "static"+ File.separator + "documents";

			//uncomment to run- String filename=empId.get().getProfileImg().getFileName();

			//String absolutePath=urlPath+File.separator+filename;
			
			//byte[] allbytes=Files.readAllBytes(new File(absolutePath).toPath());
			
			//uncomment to run- empid.getProfileImg().setImg(allbytes);
			
			System.out.println("try block executes..");
		}
		}
		catch (Exception e) {
			System.out.println("catch block executes..");
			e.printStackTrace();
		}
		
		return mapper.convertEmployeeProxyToEntity(empid);
	}
	
	//upload multiple file to dynamic path
	@Override
	public ProfileImgProxy uploadMultipleFiles(MultipartFile[] file) //working
	{
		for(int i=0;i<file.length;i++)
		{
			//uploadImgToDynamicPath(file[i]);
		}
		return null;
	}
	

	
	//download list of files
	@Override
	public void downloadListOfFiles(HttpServletResponse response) throws IOException  //working
	{
	
		response.setContentType("application/zip");
		
        response.setHeader("Content-Disposition", "attachment;filename=profileImages.zip");
        
        List<String> filenames=repo.allImg();
        
        System.out.println(filenames);
        try (ZipOutputStream zippedOut = new ZipOutputStream(response.getOutputStream()))
        {
            for (String file : filenames) {
                FileSystemResource resource = new FileSystemResource(file);
 
                ZipEntry e = new ZipEntry(resource.getFilename());
                e.setSize(resource.contentLength());
                e.setTime(System.currentTimeMillis());
                // etc.
                zippedOut.putNextEntry(e);
                StreamUtils.copy(resource.getInputStream(), zippedOut);
                zippedOut.closeEntry();
            }
            zippedOut.finish();
        } catch (Exception e) {
            e.printStackTrace();
        }
	}

	@Override
	public List<String> findByImg() { 
	return	repo.allImg();
	}

	
	//get emp objects from excel file
	@Override
	public String getObjectFromExcel(MultipartFile excelFile) { //working
		try {
			List<Employee> employeesObjs = ExcelHelper.getEmployeesObjs(excelFile.getInputStream());
			employeeRepo.saveAll(employeesObjs);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return "Data saved successfully";
	}	

	
	//downloadExcelFile with employee data
	@Override
	public ByteArrayOutputStream downloadExcelFile() //working
	{
		List<Employee> emps=employeeRepo.findAll();
		
		ByteArrayOutputStream empToExcel = ExcelHelper.empToExcel(emps);
		
		return empToExcel;
	}
	
	public byte[] downloadExcelBlankExcelFile() //working
	{
		try {
			
			String urlPath=new ClassPathResource("").getFile().getAbsolutePath() + File.separator + "static"+ File.separator + "documents";
			
			String absolutePath=urlPath+File.separator+"empBlankExcel.xlsx";
			
			File file=new File(absolutePath);
			
			byte[] allBytes=Files.readAllBytes(file.toPath());

			return allBytes;
			
		} catch (IOException e) {
	
			e.printStackTrace();
		}
		return null;
	}
}


//------------------------------------------------------------------------------------------------

/**
@Override
public EmployeeProxy downloadImgByEmpIdFromDynamicPath(Integer eid)
{
	Employee empid=null;
	
	try
	{

	Optional<Employee> empId=employeeRepo.findById(eid);
	
	if(empId.isPresent())
	{			
		String urlPath = new ClassPathResource("").getFile().getAbsolutePath() + File.separator + "static"+ File.separator + "documents";

		String filename=empId.get().getProfileImg().getFileName();

		String absolutePath=urlPath+File.separator+filename;
		
		byte[] allbytes=Files.readAllBytes(new File(absolutePath).toPath());
		
		empid.getProfileImg().setImg(allbytes);
		
		System.out.println("try block executes..");
	}
	}
	catch (Exception e) {
		System.out.println("catch block executes..");
		e.printStackTrace();
	}
	
	return mapper.convertEmployeeProxyToEntity(empid);
}
**/

/**
//upload dynamic path
@Override
public String uploadImgToDynamicPath(MultipartFile file) {

	
	//folder name for upload image,files
	String fileName=null;
	String utlPath=null;
	String pathUrl=null;
	
	String DIRPATH="uploads/";
	
	File f=new File(DIRPATH);
	
	if(!f.exists())
	{
		f.mkdir();
	}
	//object of profile img
	ProfileImg profileImg=new ProfileImg();
	
	//generate unique id for image
	String uuid=UUID.randomUUID().toString();
	
	//get orginal file name
	fileName=file.getOriginalFilename();
	
	//get last index of '.'
	int lastIndexOf=fileName.lastIndexOf(".");
	
	String ext=fileName.substring(lastIndexOf);
	
	//concat the extension and unique file id
	String finalStr=uuid.concat(ext);
	
//	String getDynamicPath=new ClassPathResource("").getFile().getAbsolutePath();
	
	profileImg.setFileId(finalStr);
	
	repo.save(profileImg);
	
	try {
		//get dynamic absolutePath
		 pathUrl="C:\\Users\\RiyaRami\\Documents\\workspace-spring-tool-suite-4-4.17.2.RELEASE\\uploadImgFile\\src\\main\\resources\\static";
		 
		 utlPath=new ClassPathResource("").getFile().getAbsolutePath();
		
		 String finalPath=utlPath+File.separator+fileName;
		 
		 System.out.println(utlPath);
		
		 //copy file path into dynamic path
		 Files.copy(file.getInputStream(),Paths.get(finalPath),StandardCopyOption.REPLACE_EXISTING);
		 
		 ProfileImg pImg=new ProfileImg();
		 pImg.setFileName(fileName);
		 pImg.setContentType(file.getContentType());
		 pImg.setFileSize(file.getSize());
		 pImg.setFileId(null);
		 
	} catch (IOException e) {
		e.printStackTrace();
	}
	return null;
}**/

