package com.example.demo.enums;

public enum GenderType {
	
	MALE,
	FEMALE;
}
